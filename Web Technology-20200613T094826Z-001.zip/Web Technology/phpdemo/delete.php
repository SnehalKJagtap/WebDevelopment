<?php

$connection=mysql_connect("localhost","root","");
echo "Connection is Successful <br>";

$query="CREATE DATABASE demophp";
$result=mysql_query($query);
echo "Database Created <br>";

$dbname="demophp";
mysql_select_db($dbname,$connection);


$srno=$_GET['rno'];

$query="delete from STUD  where rollno=$srno";
mysql_query($query);
echo "record Deleted successfully<br>";
?>