<html>
<body>

<?php
/* echo "Hello World \n";

$x=10;
$y=20;
$z=$x+$y;
echo "\n".$z;


$c=11;

if ($c%2 == 0){
    echo "Cis even=".$c;
}
else{
    echo "Cis Odd".$c;
}*/

/*
$c="";

switch($c){

    case "a":
    echo "This is green color";
    break;

    case "b":
    echo "This is green color";
    break;
    
    case "c":
    echo "This is the Blue Color";
    break;

    default:
     print "No Color Choosen";

}
*/

for($a=1;$a< 11;$a++){

    echo  ($a*2)." \n ";
}




?>
</body>
</html>
