<?php
$connection=mysql_connect("localhost","root","");
echo "Connection is Successful <br>";


$dbname="demophp";
mysql_select_db($dbname,$connection);
$query="SELECT  * from stud";
$result=mysql_query($query);
echo "Values retived successfully <br>";


while($row=mysql_fetch_assoc($result))
{
    echo "Rollno=".$row["rollno"] . "Sname=".$row["sname"]  ;

    echo "<br>";
}

?>