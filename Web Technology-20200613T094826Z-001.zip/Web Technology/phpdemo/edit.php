<?php

$connection=mysql_connect("localhost","root","");
echo "Connection is Successful <br>";

$dbname="demophp";
mysql_select_db($dbname,$connection);


$srno=$_GET['rno'];

$ssname=$_GET['sname'];

$query="UPDATE STUD SET sname=$ssname WHERE rollno=$srno";
mysql_query($query);
echo "record inserted successfully<br>";







?>