
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
     
    @Override
    protected void doGet(HttpServletRequest request,
HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        String uid=request.getParameter("uid");
        String pwd=request.getParameter("pass");
       
        if(uid.equals("admin")&& pwd.equals("admin"))
        {
             PrintWriter pw=response.getWriter();
             pw.println("<html><body> Welcome " +uid);
             pw.println("</body></html>");
             pw.close();
        }
        else{
         RequestDispatcher rd=request.getRequestDispatcher("index.html");
         rd.forward(request,response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       

    }
}
