<?php

$connection=mysql_connect("localhost","root","");
echo "Connection is Successful <br>";

$query="CREATE DATABASE demophp";
$result=mysql_query($query);
echo "Database Created <br>";

$dbname="demophp";
mysql_select_db($dbname,$connection);
$query="CREATE TABLE STUD(rollno INT(6),sname VARCHAR(30))";
$result=mysql_query($query);
echo "Table created successfully <br>";


$srno=$_GET['rno'];

$ssname=$_GET['sname'];

$query="insert into STUD values(";
$query=$query.$srno.",'".$ssname;
$query=$query."')";
mysql_query($query);
echo "record inserted successfully<br>";







?>