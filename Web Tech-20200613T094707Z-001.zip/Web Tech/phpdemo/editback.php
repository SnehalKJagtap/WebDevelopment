
EDITBACK.PHP
===============================

<html>
<head>

</head>


<body>

<form action="edit.php" method="get">

Rollno<input type="text" name="rno" id="rno" >  <br>

Sname<input type="text" name="sname"  id="sname">  <br>

<input type="submit" name="UPDATE" value="UPDATE"> 
</form>
</body>
</html>
