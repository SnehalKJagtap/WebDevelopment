<?php

$con=mysql_connect("localhost","root","");
echo "Connection with mysql is successful<br>";

$db=mysql_select_db("my_db",$con);
echo "Database selected<br>";

$quer="CREATE TABLE stud(rol_no INT(5),s_name VARCHAR(10),s_marks INT(20))";
$result=mysql_querry($quer);
echo "Table created successfully<br>";

$quer="INSERT INTO stud VALUES(101,'Mahesh',88)<br>";
$result=mysql_querry($quer);
echo "Record successfully inserted<br>";

?>