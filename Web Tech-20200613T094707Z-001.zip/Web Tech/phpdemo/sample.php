<?php

$connection=mysql_connect("localhost","root","");
echo "Connection is Successful <br>";

$query="CREATE DATABASE demo";
$result=mysql_query($query);
echo "Database Created <br>";

$dbname="demo";
mysql_select_db($dbname,$connection);
$query="CREATE TABLE STUD(rollno INT(6),sname VARCHAR(30))";
$result=mysql_query($query);
echo "Table created successfully <br>";


$query="insert into STUD values(1,'pqr')";
$result=mysql_query($query);
echo "record inserted successfully<br>";

$query="SELECT  * from stud";
$result=mysql_query($query);
echo "Values retived successfully <br>";

while($row=mysql_fetch_assoc($result))
{
    echo "Rollno=".$row["rollno"] . "Sname=".$row["sname"]  ;

    echo "<br>";
}






?>