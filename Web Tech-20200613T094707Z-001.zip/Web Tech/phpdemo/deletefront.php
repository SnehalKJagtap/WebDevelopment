DELETEFRONT.PHP
================================================================
<html>
<head>

</head>


<body>

<form action="delete.php" method="get">

Rollno<input type="text" name="rno" id="rno" >  <br>
<input type="submit" name="Delete" value="Delete"> 
</form>

</body>

</html>
