Insert.php

<?php
$name=$_GET['username'];
echo " WELCOME <br>";
echo "$name";
?>

